<?php
if ($_POST["filter"] != null) {
	$filter = $_POST["filter"];
}
$count = 0;
$groupCount = array();
$groupStars = array();
//$colors = array("#ff3030", "#ffff00", "#00ff00", "#80c0ff");
$colors = array("#ff3030", "#00ff00");
$donecolor = "#000000";
$coachmail[0] = "mailto:" . $profmail;
$groupmail = array();
for ($i = 1; $i <= $nGroups+1; $i++) {
	$coachmail[0] .= $coachmail[$i];
	$coachmail[$i] = "mailto:" . $coachmail[$i];
	$groupmail[$i] = $coachmail[$i];
}
$groupmail[0] = $coachmail[0];

if (file_exists($filename)) {
	// gepostete Variablen speichern (sofern welche kamen)
	$comment = $_POST["comment"];
	$mat = $_POST["mat"];
	$karte = $_POST["karte"];
	$star = $_POST["star"];
	$group = $_POST["group"];
	$link = $_POST["link"];
	// Sicherheitskopie der Link-Datei anfertigen, falls Variablen kamen...
	copy($filename, "backup/" . $filename . "_" . filemtime($filename) . ".xml");
	// xml per dom laden und verarbeiten
	$dom = new domDocument("1.0", "utf-8");
	//header("Content-Type: text/plain");
	$dom -> load($filename);
	foreach ($dom->getElementsByTagName('node') as $index => $node) {		
		$groupmail[0] .= $node -> getAttribute('email') . ',';
		$groupmail[$node -> getAttribute('group')] .= $node -> getAttribute('email') . ',';
		// verarbeite Feedback der Betreuer
		if ($UserRole == "Betreuer" || $UserRole == "Prof") {
			if (!empty($_POST) && $node -> getAttribute('mat') == $mat) {
				//$node->setAttribute('feed', date('j.n.|H:i'));
				$comment=str_replace("\r\n", "\n", $comment);
				if ($node -> firstChild -> nodeValue != utf8_encode($comment)) {
					$new = $dom -> createCDATASection(date('j.n.|H:i') . " " . utf8_encode($comment));
					$node -> replaceChild($new, $node -> firstChild);
				}
				if ($link != null && $link != $node -> getAttribute('link'))
				$node -> setAttribute('link', $link);

				if ($karte != null)
				$node -> setAttribute('done', $karte);

				if ($star != null)
				$node -> setAttribute('star', $star);

				if ($star != null)
				$node -> setAttribute('group', $group);
			}
			if ($filter) {
				if ($node -> getAttribute('group') != $filter)
					continue;
			}
		}
		
		$iGroup = $node -> getAttribute('group');
		$color = $colors[$iGroup - 1];
		$groupCount[$iGroup]++;
		$warn = $node -> getAttribute('done');
		$nStar = $node -> getAttribute('star');
		$groupStars[$iGroup] += $nStar;
		
		print '<div id="' . $node -> getAttribute('mat') . '" style="position:relative; height:120px">';
		print '<img src="' . $node -> getAttribute('link') . '/portrait.jpg" width="85" height="110">';
		print '<div style="position:absolute; top:0px; left:90px; height:20px; margin:0px; padding:0px; background:' . $color . '">';
		print $node -> getAttribute('name') . ',' . $node -> getAttribute('first') . ' | ' . $node -> getAttribute('mat') . ' | ' . $node -> getAttribute('cur') . $node -> getAttribute('sem') . '</br>';
		print '<iframe id="f' . $count . '" src=' . $node -> getAttribute('link') . '/steckbrief.htm width="400" height="94" marginheight="0" marginwidth="0" scrolling="auto" frameborder="0"></iframe></div></br>';
		print '<div style="position:absolute; top:2px; left:2px">';
		print '<a href="mailto:' . $node -> getAttribute('email') . '"><img src="../Pics/mail.gif" alt="mail" title="E-Mail an Person" border="0"></a>';
		for ($iStar = 0; $iStar < $nStar; $iStar++) {
			print '<img src="../Pics/star.gif" alt="star" title="Star" border="0" width="18" height="12">';
		}
		if (isset($showDatabase)){
			if ($showDatabase) {
				print '<a href="showDatabase.php?mat=' . $node -> getAttribute('mat') . '" target="_blank">';
				print '<img src="../Pics/tabelle.gif" alt="showDatabase" title="Datenbank anzeigen" border="0">';
				print '</a>';			
			}
		}
		print '</div>';
		
		for ($iWarn = 0; $iWarn < $warn; $iWarn++) {
			print '<div style="position:absolute; top:' . (16 + $iWarn * 20) . 'px; left:2px">';
			print '<img src="../Pics/' . ($iWarn < 2 ? 'gelb.gif' : 'rot.gif') . '" alt="" border="0">';
			print '</div>';
		}
		// div mit Betreuerformular oder Kommentar
		print '<div style="position:absolute; border: 1px solid #0; overflow:hidden; top:0px; left:502px; width:320px; height:110px; background:#eeeeee">';
		if ($UserRole == "Betreuer" || $UserRole == "Prof") {
			print '<form action="' . $currentFile . '#' . $node -> getAttribute('mat') . '" method="POST">';
			print 'Feedback ';
			if ($UserRole == "Prof") { 				 
				if ($nGroups > 0) { 
					print ' | <select name="group">';
					foreach ($description as $groupNumber => $groupName) {
						$s = ($iGroup == $groupNumber) ? "selected" : "";
						print "<option value='$groupNumber' title='$groupName' $s>$groupNumber</option>";
					}
					print("</select>");
					print('<img src="../Pics/group.gif" border="0" title="Gruppe wechseln"/>');
				}
				
				print ' | <select name="karte">';
				print '<option value="0" title="keine Karte"'.($warn==0?" selected":"").'>0</option>';
				print '<option value="1" title="eine Gelbe"'.($warn==1?" selected":"").'>1</option>';
				print '<option value="2" title="zwei Gelbe"'.($warn==2?" selected":"").'>2</option>';
				print '<option value="3" title="rote Karte"'.($warn==3?" selected":"").'>3</option>';
				print '</select>';
				print '<img src="../Pics/gelb.gif" border="0" title="Karten vergeben"/>';
				
				print ' | <select name="star">';
				print '<option value="0" title="kein Stern"'.($nStar==0?" selected":"").'>0</option>';
				print '<option value="1" title="einen Stern"'.($nStar==1?" selected":"").'>1</option>';
				print '<option value="2" title="zwei Sterne"'.($nStar==2?" selected":"").'>2</option>';
				print '<option value="3" title="drei Sterne"'.($nStar==3?" selected":"").'>3</option>';
				print '</select>';
				print '<img src="../Pics/star.gif" border="0" title="Sterne vergeben"/> | ';
				print '<input type="text" size="1" name="link" value="' . $node -> getAttribute('link') . '" title="Steckbrief-Pfad ändern" onclick="(function(_t){var n = prompt(\'Pfad zum Steckbrief\',_t.value); _t.value = (n ? n:_t.value);})(event.target)">';
			}
			print '<input type="submit" value="post" title="Kommentar und Kartenvergabe posten!"><input type="hidden" value="' . $node -> getAttribute('mat') . '" name="mat"><input type="hidden" value="' . $filter . '" name="filter"></br>';
			print '<textarea style="resize: none" name="comment" cols="36" rows="4">' . utf8_decode($node -> firstChild -> nodeValue) . '</textarea>';
			print '</form>';
		} else {
			print 'Feedback</br>';
			print '<textarea style="resize: none" name="comment" cols="36" rows="4">' . utf8_decode($node -> firstChild -> nodeValue) . '</textarea>';
		}
		print '</div>';
		print '</div>';
		$count++;
	}
} else {
	die("The file $filename does not exist");
}
print "Anzahl:$count<br/>";

foreach ($groupCount as $groupNumber => $count) {
	print($description[$groupNumber]);
	print("<span style='position:absolute;left:300px;height:20px'>");
	print("<img src='../Pics/group.gif' border='0'> $count ");
	for ($i=0; $i < $groupStars[$groupNumber]; $i++) {
		print("<img src='../Pics/star.gif' border='0'>");
	}
	print("</span><br/>");
}
print("<br/>");

if (!empty($_POST)) {
	$dom -> preserveWhiteSpace = false;
	$dom -> formatOutput = true;
	// ...cosmetics done... save!
	//print "Save";
	$dom -> save($filename);
}
?>
