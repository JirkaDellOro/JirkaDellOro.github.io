// validate email-adress
function isMail(tMail) {
	var strReg = "^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$";

	var regex = new RegExp(strReg);
	return regex.test(tMail);
}

// validate link
function isURL(tUrl) {
	var regex = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
	var bTest = regex.test(tUrl);
	return (bTest);
}

function queryFile(_url) {
	var xmlhttp;
	var status = true;
	xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET", _url, false);
	//xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.onreadystatechange = serverAnswer;
	xmlhttp.onerror = errorMethod;
	xmlhttp.send(null);
	return status;

	// wird aufgerufen, wenn die Daten verschickt wurden und vom Server die Antwort kam
	function serverAnswer() {
		//alert("Answer\nReady: " + xmlhttp.readyState + "\nStatus: " + xmlhttp.statusText);
		status = status && (xmlhttp.statusText == "OK");
	}

	function errorMethod() {
		//alert("Error\nReady: " + xmlhttp.readyState + "\nStatus: " + xmlhttp.statusText);
		status = false;
	}

}

// validate data
function checkData() {
	try {
		if (isMail(document.anmeldung.email.value)) {
			var path = document.anmeldung.link.value;
			if (isURL(path)) {
				if (true) { //(queryFile(path + "/steckbrief.htm") && !(queryFile(path + "/xyz321__asd.alsvn.lkje"))) {
					setSalt();
					return true;
				} else {
					alert("Datei 'steckbrief.htm' im angegebenen Pfad nicht gefunden!");
				}
			} else {
				alert("Bitte einen korrekten Pfad angeben");
			}
		} else {
			alert("Bitte eine korrekte E-Mail-Adresse angeben");
		}
	} catch (_e) {
		alert("Bitte einen korrekten Pfad angeben");
	}
	return false;
}

// prompt user to input validation-code
function promptCode() {
	var code = prompt("Bitte den Aktivierungscode aus der E-Mail hier hineinkopieren");
	if (code != null) {
		document.anmeldung.code.value = code;
		document.anmeldung.submit();
	}
}

function setSalt() {
	if (document.anmeldung.salt1.value == "")
		document.anmeldung.salt1.value = String.fromCharCode(65 + parseInt(Math.random() * 26));
}