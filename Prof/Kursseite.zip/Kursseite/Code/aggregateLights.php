<?php
/* AggregateLights.php | (c) Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl | HFU
 * 
 * Generierung der HTML-Darstellung der Steckbriefe und Kommentare aus dem XML-File und dessen Modifikation
 * 	- liest die XML-Datei $filename
 * 	- erstellt für jeden Knoten ein div-Element für einen Steckbrief
 * 	- stellt darin Kopfzeile, Portrait, Ampeln, Sternchen, Steckbriefinhalt (iframe) und Kommentar dar
 * 		- ist $UserRole "Betreuer" oder "Prof" ist der Kommentar in ein Formular mit Post-Button eingebettet
 * 		- ist $UserRole "Prof" sind im Formular zusätzlich die Buttons zu Gruppenwechsel, Karten- und Sternvergabe sichtbar
 * 	- Post-Daten werden nur bei $UserRole "Betreuer" oder "Prof" ausgewertet (außer "filter" zur Darstellungsreduktion)
 * 		- Sicherheitskopie der XML-Datei mit Zeitstempel wird angelegt
 * 		- Knotendaten werden mit Post-Daten überschrieben
 * 		- XML-Datei wird überschrieben
 * 	- Zusammenfassung der Anzahl der Einträge und Sternchen pro Gruppe wird ausgegeben
 */

if ($_POST["filter"] != null) {
	$filter = $_POST["filter"];
}
$count = 0;
$groupCount = array();
$groupStars = array();
//$colors = array("#ff3030", "#ffff00", "#00ff00", "#80c0ff");
$colors = array("#ff3030", "#00ff00", "#ffff00");
$donecolor = "#000000";
$coachmail[0] = "mailto:" . $profmail;
$groupmail = array();
for ($i = 1; $i <= $nGroups + 1; $i++) {
	$coachmail[0] .= $coachmail[$i];
	$coachmail[$i] = "mailto:" . $coachmail[$i];
	$groupmail[$i] = $coachmail[$i];
}
$groupmail[0] = $coachmail[0];

if (!file_exists($filename))
	die("The file $filename does not exist");

// gepostete Variablen speichern (sofern welche kamen)
$comment = $_POST["comment"];
$mat = $_POST["mat"];
$karte = $_POST["karte"];
$star = $_POST["star"];
$group = $_POST["group"];
$link = $_POST["link"];

// Sicherheitskopie der XML-Datei anfertigen, falls Feedback kam...
$modify = (isset($comment) && ($UserRole == "Betreuer" || $UserRole == "Prof"));
if ($modify)
	copy($filename, "backup/" . $filename . "_" . filemtime($filename) . ".xml");

// xml per dom laden und verarbeiten
$dom = new domDocument("1.0", "utf-8");
$dom -> load($filename);

foreach ($dom->getElementsByTagName('node') as $index => $node) {
	$groupmail[0] .= $node -> getAttribute('email') . ',';
	$groupmail[$node -> getAttribute('group')] .= $node -> getAttribute('email') . ',';

	// verarbeite Feedback der Betreuer
	if ($modify) {
		if ($node -> getAttribute('mat') == $mat)
			modifyNode($node);
	}

	$iGroup = $node -> getAttribute('group');
	// keine Darstellung wenn Gruppe gefiltert
	if ($filter) {
		if ($iGroup != $filter)
			continue;
	}
	$color = $colors[$iGroup - 1];
	$groupCount[$iGroup]++;
	$warn = $node -> getAttribute('done');
	$nStar = $node -> getAttribute('star');
	$groupStars[$iGroup] += $nStar;

	print '<div id="' . $node -> getAttribute('mat') . '" style="position:relative; height:120px">';
	showStudentData($node);

	// div mit Betreuerformular oder Kommentar
	print '<div style="position:absolute; border: 1px solid #0; overflow:hidden; top:0px; left:502px; width:320px; height:110px; background:#eeeeee">';

	if ($UserRole == "Betreuer" || $UserRole == "Prof") {
		print '<form action="' . $currentFile . '#' . $node -> getAttribute('mat') . '" method="POST">';
		print 'Feedback ';

		if ($UserRole == "Prof")
			showAdditionalButtons($node);

		print '<input type="submit" value="post" title="Kommentar und Kartenvergabe posten!"><input type="hidden" value="' . $node -> getAttribute('mat') . '" name="mat"><input type="hidden" value="' . $filter . '" name="filter"></br>';
		showComment($node);
		print '</form>';
	} else {
		print 'Feedback</br>';
		showComment($node);
	}

	// Feedback
	print '</div>';
	// StudentData
	print '</div>';
	$count++;
}

print "Anzahl:$count<br/>";

foreach ($groupCount as $groupNumber => $count) {
	print($description[$groupNumber]);
	print("<span style='position:absolute;left:300px;height:20px'>");
	print("<img src='../Pics/group.gif' border='0'> $count ");
	for ($i = 0; $i < $groupStars[$groupNumber]; $i++) {
		print("<img src='../Pics/star.gif' border='0'>");
	}
	print("</span><br/>");
}
print("<br/>");

if ($modify) {
	$dom -> preserveWhiteSpace = false;
	$dom -> formatOutput = true;
	// ...cosmetics done... save!
	//print "Save";
	$dom -> save($filename);
}

function modifyNode($_node) {
	global $dom, $comment, $mat, $karte, $star, $group, $link;
	//$node->setAttribute('feed', date('j.n.|H:i'));
	$comment = str_replace("\r\n", "\n", $comment);
	if ($_node -> firstChild -> nodeValue != utf8_encode($comment)) {
		$new = $dom -> createCDATASection(date('j.n.|H:i') . " " . utf8_encode($comment));
		$_node -> replaceChild($new, $_node -> firstChild);
	}
	if ($link != null && $link != $_node -> getAttribute('link'))
		$_node -> setAttribute('link', $link);

	if ($karte != null)
		$_node -> setAttribute('done', $karte);

	if ($star != null)
		$_node -> setAttribute('star', $star);

	if ($star != null)
		$_node -> setAttribute('group', $group);
}

function showStudentData($_node) {
	global $color, $warn, $count, $nStar;
	print '<img src="' . $_node -> getAttribute('link') . '/portrait.jpg" width="85" height="110">';
	print '<div style="position:absolute; top:0px; left:90px; height:18px; margin:0px; padding:0px; background:' . $color . '">';
	print $_node -> getAttribute('name') . ', ' . $_node -> getAttribute('first') . ' | ' . $_node -> getAttribute('mat') . ' | ' . $_node -> getAttribute('cur') . $_node -> getAttribute('sem') . '<br/>';
	print '<img src="../Pics/LightsBig' . $warn . '.png" alt="" border="0" style="position:absolute; right:0px; top:0px; height:16px">';
	print '<iframe id="f' . $count . '" src=' . $_node -> getAttribute('link') . '/steckbrief.htm width="400" height="94" marginheight="0" marginwidth="0" scrolling="auto" frameborder="0"></iframe></div></br>';
	print '<div style="position:absolute; top:2px; left:2px">';
	print '<a href="mailto:' . $_node -> getAttribute('email') . '"><img src="../Pics/mail.gif" alt="mail" title="E-Mail an Person" border="0"></a>';
	for ($iStar = 0; $iStar < $nStar; $iStar++) {
		print '<img src="../Pics/star.gif" alt="star" title="Star" border="0" width="18" height="12">';
	}
	/* für GiS
	 if (isset($showDatabase)) {
	 if ($showDatabase) {
	 print '<a href="showDatabase.php?mat=' . $_node -> getAttribute('mat') . '" target="_blank">';
	 print '<img src="../Pics/tabelle.gif" alt="showDatabase" title="Datenbank anzeigen" border="0">';
	 print '</a>';
	 }
	 }
	 */
	print '</div>';
}

function showAdditionalButtons($_node) {
	global $nGroups, $description, $groupNumber, $iGroup, $warn, $nStar;
	if ($nGroups > 0) {
		print ' | <select name="group">';
		foreach ($description as $groupNumber => $groupName) {
			$s = ($iGroup == $groupNumber) ? "selected" : "";
			print "<option value='$groupNumber' title='$groupName' $s>$groupNumber</option>";
		}
		print("</select>");
		print('<img src="../Pics/group.gif" border="0" title="Gruppe wechseln"/>');
	}

	print ' | <select name="karte">';
	print '<option value="0" title="Grün"' . ($warn == 0 ? " selected" : "") . '>0</option>';
	print '<option value="1" title="Grün-Gelb"' . ($warn == 1 ? " selected" : "") . '>1</option>';
	print '<option value="2" title="Gelb"' . ($warn == 2 ? " selected" : "") . '>2</option>';
	print '<option value="3" title="Gelb-Rot"' . ($warn == 3 ? " selected" : "") . '>3</option>';
	print '<option value="4" title="Rot"' . ($warn == 4 ? " selected" : "") . '>4</option>';
	print '</select>';
	print '<img src="../Pics/LightsSmall.png" border="0" title="Karten vergeben"/>';

	print ' | <select name="star">';
	print '<option value="0" title="kein Stern"' . ($nStar == 0 ? " selected" : "") . '>0</option>';
	print '<option value="1" title="einen Stern"' . ($nStar == 1 ? " selected" : "") . '>1</option>';
	print '<option value="2" title="zwei Sterne"' . ($nStar == 2 ? " selected" : "") . '>2</option>';
	print '<option value="3" title="drei Sterne"' . ($nStar == 3 ? " selected" : "") . '>3</option>';
	print '</select>';
	print '<img src="../Pics/star.gif" border="0" title="Sterne vergeben"/> | ';
	print '<input type="text" size="1" name="link" value="' . $_node -> getAttribute('link') . '" title="Steckbrief-Pfad ändern" onclick="(function(_t){var n = prompt(\'Pfad zum Steckbrief\',_t.value); _t.value = (n ? n:_t.value);})(event.target)">';
}

function showComment($_node) {
	print '<textarea style="resize: none" name="comment" cols="36" rows="4">' . utf8_decode($_node -> firstChild -> nodeValue) . '</textarea>';
}
?>
