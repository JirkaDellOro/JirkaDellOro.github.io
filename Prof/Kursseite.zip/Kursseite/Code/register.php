<?php
	/*
		Validierung und integration der Links zu den Steckbriefen der Teilnehmer
		(c) Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl, HFU
	*/
	
	// acquire posted variables
	$link = $_POST["link"];
	$email = $_POST["email"];
	$code = $_POST["code"];
	$name = htmlentities($_POST["name"]);
	$first = htmlentities($_POST["first"]);
	$mat = $_POST["mat"];
	$cur = $_POST["cur"];
	$sem = $_POST["sem"];
	$group = $_POST["group"];
	$salt1 = $_POST["salt1"];
	$salt2 = "x";
	
	function addLink($link, $email, $name, $first, $mat, $cur, $sem, $group) {
		$filename = getFilename();
		$id = 0;
		if (file_exists($filename)) 
		{
			copy($filename, "backup/".$filename."_".filemtime($filename).".xml");
			$dom = new domDocument("1.0", "utf-8");
			$dom->preserveWhiteSpace = false;
			$dom->formatOutput = true;
			$dom->load($filename);
			foreach($dom->getElementsByTagName('node') as $index => $node) {
				if ($node->getAttribute("mat") == $mat) {
					echo "Fehler: Matrikelnummer ist schon eingetragen worden, bitte pr&uuml;fen Sie Ihre Eingabe!<br/>";
					echo "Verwenden Sie ggf. eine Fantasienummer und melden Sie das Problem beim Prof!\n";
					die;
				}
			}
			$newNode = $dom->createElement("node");
			$dom->getElementsByTagName("links")->item(0)->appendChild($newNode);
			$newNode->appendChild($dom->createCDATASection("Willkommen im Kurs!"));
			$newNode->setAttribute("name", $name);
			$newNode->setAttribute("first", $first);
			$newNode->setAttribute("mat", $mat);
			$newNode->setAttribute("cur", $cur);
			$newNode->setAttribute("sem", $sem);
			$newNode->setAttribute("email", $email);
			$newNode->setAttribute("link", $link);
			$newNode->setAttribute("group", $group);
			$newNode->setAttribute("done", 0);
			$dom->save($filename);
		} 
		else 
		{
			print "The file $filename does not exist";
			die;
		}
	}
			
	$prompt = "";
	if ($_POST)	{
		$encrypted = crypt($email, $salt1.$salt2);
		if ($code) {
			if ($code == $encrypted) {
				echo "Code korrekt...<br/><br/>";
				addLink($link, $email, $name, $first, $mat, $cur, $sem, $group);
				echo "Viel Erfolg!";
			} else {
				echo "Falscher Code, Aktivierung nicht m&ouml;glich!\n";
			}
			$salt1 = "";
			die;
		}
		else {
			$message = "Hallo $first,\n\n";
			$message .= "Ihre Angaben waren\n";
			$message .= "Nachname: $name\n";
			$message .= "Matrikel: $mat\n";
			$message .= "Studiengang: $cur\n";
			$message .= "Semester: $sem\n";
			$message .= "Gruppe: $description[$group]\n";
			$message .= "Ordner: $link\n\n";
			$message .= "Erst wenn Sie ganz sicher sind, dass alles korrekt ist, kopieren Sie den Aktivierungscode in die Eingabeaufforderung auf der Website und klicken Sie dann auf 'OK'. Ansonsten klicken Sie auf 'Abbrechen' und korrigieren Sie entsprechend. Nach der Registrierung sind die Daten nicht mehr modifizierbar!\n\n";
			$message .= "Der Aktivierungscode Ihrer Registrierung lautet\n";
			$message .= $encrypted."\n\n";
			//sendmail("del@hs-furtwangen.de", $email, "Aktivierungscode", $message);
			mail( $email, "Aktivierungscode", $message, "From: del@hs-furtwangen.de");
			$prompt = 'onLoad="promptCode()"';
		}
	}
?>
<html>
	<head>
		<TITLE>Anmeldeformular</TITLE>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
		<script src="../Code/register.js" type="text/javascript"></script>
	</head>
	<body bgcolor="#FFFFFF" <?php echo $prompt?> >
		<div style="position:fixed; right:20px; top:5px"><img src="../Pics/logo.png" alt="logo" border="0"></div>
		<div style="position:absolute; top:20px; font-family:arial; font-size:small">
		  <form action="<?php $currentFile ?>" method="POST" name="anmeldung" id="anmeldung" onSubmit="return checkData();">
			<table width="673" border="0" cellspacing="2" cellpadding="2" style="font-family:arial; font-size:small">
			  <tr>
				<td height="98" colspan="2"><p>Steckbriefregistrierung f&uuml;r <b>"<?php print $title?>"</b> an. F&uuml;llen Sie bitte die untenstehenden Felder aus.<br/>
					<strong>Achtung</strong>: Sie k&ouml;nnen die Informationen nachtr&auml;glich nicht editieren.<br/>
				  Achten Sie also vor dem Abschicken genau darauf, dass alle Angaben korrekt sind!<br/></p>
				</td>
			  </tr>
			  <tr>
				<td width="138">Name:</td>
				<td width="491"><input type="text" name="name" <?php echo "value=".($name ? $name:'""') ?>  size="50" maxlength="50"/></td>
			  </tr>
			  <tr>
				<td>Vorname:</td>
				<td><input type="text" name="first" <?php echo "value=".($first ? $first:'""') ?>  size="50" maxlength="50"/></td>
			  </tr>
			  <tr>
				<td>Matrikelnummer:</td>
				<td><input type="text" name="mat" <?php echo "value=".($mat ? $mat:'""') ?>  size="6" maxlength="6"/></td>
			  </tr>
			  <tr>
				<td>Studiengang:</td>
				<td><!--input type="text" name="cur" <?php echo "value=".($cur ? $cur:'""') ?>  size="3" maxlength="3"/-->
				 <select name="cur" size="1">
				  <option value="MIB" <?php echo ($cur=="MIB" ? 'selected':'') ?>>MIB</option>
				  <option value="MKB" <?php echo ($cur=="MKB" ? 'selected':'') ?>>MKB</option>
				  <option value="OMB" <?php echo ($cur=="OMB" ? 'selected':'') ?>>OMB</option>
				  <option value="MIM" <?php echo ($cur=="MIM" ? 'selected':'') ?>>MIM</option>
				  <option value="DIM" <?php echo ($cur=="DIM" ? 'selected':'') ?>>DIM</option>
				  <option value="---" <?php echo ($cur=="---" ? 'selected':'') ?>>---</option>
				</select>
				&nbsp;&nbsp;Semester:<input type="text" name="sem" <?php echo "value=".($sem ? $sem:'""') ?>  size="1"  maxlength="1"/>
				</td>
			  </tr>
			  <?php 
				  if ($nGroups > 1) {
				  print("<tr><td>Bevorzugte Gruppe:</td><td><select name='group' size='1'>");
					for ($iGroup =1; $iGroup <= $nGroups; $iGroup++) {
						print ('<option value="'.$iGroup.'" '.($group==$iGroup ? 'selected':'').'>');
						print ($description[$iGroup]);
						print ('</option>');
					}
				  	print("</select></td></tr>");
				  }
			 ?>
			  <tr>
				<td colspan="2" height="102">Tragen Sie hier die E-Mail-Adresse ein, welche Sie im Verlauf der Veranstaltung nutzen werden.<br/>
				Sie muss sofort erreichbar sein, da Sie dort einen Aktivierungscode f&uuml;r die Anmeldung erhalten werden.<br/>
				<input type="text" name="email" <?php echo "value=".($email ? $email:'""') ?>  size="50"/></td>
			  </tr>
			  <tr>
				<td height="102" colspan="2"> Geben Sie hier den HTTP-Pfad des Ordners an, ihn dem Ihre Dateien "steckbrief.htm" und "portrait.jpg" liegen.
<input type="text" name="link" <?php echo "value=".($link ? $link:'""')?> size="100"/></td>
			  </tr>
			</table>
			<p>
			<input type="hidden" name="code" value="" size="50"><input type="hidden" name="salt1" <?php echo "value=".($salt1 ? $salt1:'""') ?> size="1">
			 <input type="submit" value="Registrieren">
			</form>
		  <p style="font-size: small">&copy; Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl, HFU</p>
		</div>
</body>
</html>

