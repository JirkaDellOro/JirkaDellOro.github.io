<?php
if ($_POST["filter"] != null) {
	$filter = $_POST["filter"];
}
$count = 0;
$colors = array("#ff0000", "#ffff00", "#00ff00", "#0000ff");
$donecolor = "#000000";
$coachmail[0] = "mailto:" . $coachmail[0] . $coachmail[1] . $coachmail[2] . $coachmail[3];
$groupmail = array();
$groupmail[0] = $coachmail[0];
$coachmail[1] = "mailto:" . $coachmail[1];
$coachmail[2] = "mailto:" . $coachmail[2];
$coachmail[3] = "mailto:" . $coachmail[3];
$groupmail[1] = $coachmail[1];
$groupmail[2] = $coachmail[2];
$groupmail[3] = $coachmail[3];
if (file_exists($filename)) {
	// gepostete Variablen speichern (sofern welche kamen)
	$comment = $_POST["comment"];
	$mat = $_POST["mat"];
	$karte = $_POST["karte"];
	// Sicherheitskopie der Link-Datei anfertigen, falls Variablen kamen...
	copy($filename, "backup/" . $filename . "_" . filemtime($filename) . ".xml");
	// xml per dom laden und verarbeiten
	$dom = new domDocument("1.0", "utf-8");
	//header("Content-Type: text/plain");
	$dom -> load($filename);
	foreach ($dom->getElementsByTagName('node') as $index => $node) {
		// verarbeite Feedback der Betreuer
		if ($UserRole == "Betreuer") {
			if (!empty($_POST) && $node -> getAttribute('mat') == $mat) {
				//$node->setAttribute('feed', date('j.n.|H:i'));
				if ($node -> firstChild -> nodeValue != utf8_encode($comment)) {
					$new = $dom -> createCDATASection(date('j.n.|H:i') . " " . utf8_encode($comment));
					$node -> replaceChild($new, $node -> firstChild);
				}
				if ($karte != null) {
					$node -> setAttribute('done', $karte);
				}
			}
			if ($filter) {
				if ($node -> getAttribute('group') != $filter)
					continue;
			}
		}
		$color = $colors[$node -> getAttribute('group') - 1];
		$warn = "gelb.gif";
		if ($node -> getAttribute('done') == 2) {
			$warn = "rot.gif";
		}
		print '<div id="' . $node -> getAttribute('mat') . '" style="position:relative; height:120px">';
		print '<img src="' . $node -> getAttribute('link') . '/portrait.jpg" width="85" height="110">';
		print '<div style="position:absolute; top:0px; left:90px; background:' . $color . '">';
		print $node -> getAttribute('name') . ',' . $node -> getAttribute('first') . ' | ' . $node -> getAttribute('mat') . ' | ' . $node -> getAttribute('cur') . $node -> getAttribute('sem') . '</br>';
		print '<iframe id="f' . $count . '" src=' . $node -> getAttribute('link') . '/steckbrief.htm width="400" height="94" marginheight="0" marginwidth="0" scrolling="auto" frameborder="0" style="border-color:' . $color . '"></iframe></div></br>';
		print '<div style="position:absolute; top:2px; left:2px">';
		print '<a href="mailto:' . $node -> getAttribute('email') . '"><img src="../../Pics/mail.gif" alt="mail" title="E-Mail an Person" border="0"></a>';
		for ($star = 0; $star < $node -> getAttribute('star'); $star++) {
			print '<img src="../../Pics/star.gif" alt="star" title="Star" border="0" width="18" height="12">';
		}
		print '</div>';
		if ($node -> getAttribute('done') > 0) {
			print '<div style="position:absolute; top:16px; left:2px">';
			print '<img src="../../Pics/' . $warn . '" alt="" border="0">';
			print '</div>';
		}
		// div mit Betreuerformular oder Kommentar
		print '<div style="position:absolute; border: 1px solid #0; overflow:hidden; top:0px; left:502px; width:320px; height:110px; background:#eeeeee">';
		if ($UserRole == "Betreuer") {
			print '<form action="' . $currentFile . '#' . $node -> getAttribute('mat') . '" method="POST">';
			print 'Feedback <input type="radio" name="karte" title="Karte löschen" value="0" title=""><img src="../../Pics/delete.gif" border="0"/> <input type="radio" name="karte" title="Gelbe Karte vergeben" value="1" title=""><img src="../../Pics/gelb.gif" border="0"/> <input type="radio" name="karte" title="Rote Karte vergeben" value="2" title=""><img src="../../Pics/rot.gif" border="0"/> <input type="submit" value="post" title="Kommentar und Kartenvergabe posten und per Mail senden!"><input type="hidden" value="' . $node -> getAttribute('mat') . '" name="mat"><input type="hidden" value="' . $filter . '" name="filter"></br>';
			print '<textarea style="resize: none" name="comment" cols="36" rows="4">' . utf8_decode($node -> firstChild -> nodeValue) . '</textarea>';
			print '</form>';
		} else {
			print 'Feedback</br>';
			print '<textarea style="resize: none" name="comment" cols="36" rows="4">' . utf8_decode($node -> firstChild -> nodeValue) . '</textarea>';
		}
		print '</div>';
		print '</div>';
		$groupmail[0] .= $node -> getAttribute('email') . ',';
		$groupmail[$node -> getAttribute('group')] .= $node -> getAttribute('email') . ',';
		$count++;
	}
} else {
	die("The file $filename does not exist");
}
print 'Anzahl: ' . $count;

if (!empty($_POST) && $_POST["form"] != "filter") {
	$dom -> preserveWhiteSpace = false;
	$dom -> formatOutput = true;
	// ...cosmetics done... save!
	//print "Save";
	$dom -> save($filename);
}
?>