<?php
/*
 Kursseite mit Aggregation der Steckbriefe der Teilnehmer
 (c) Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl, HFU
 */
// includes
include "authorize.php";
$filename = getFilename();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="icon" href="../Pics/VSCodeLogo.gif" type="image/gif" />
		<script type="text/javascript">
			function Refresh() {
				var iCount = 0;
				var oFrame;
				while(( oFrame = document.getElementById("f" + iCount)) != null) {
					//oFrame.contentWindow.location.reload(true);
					oFrame.src = oFrame.src + "?r=" + Math.round(Math.random() * 1000000);
					iCount++;
				}
			}
		</script> 
		<title><?php print $title.$titleExtension;?></title>
</head>
<body bgcolor="#eeeeee" onLoad="Refresh()">
	<div style="position:absolute; top:5px; left:260px; width:830px; overflow:auto; font-family:arial; font-size:small">
		<?php include "../Code/aggregateLights.php" ?>
</div>
<div style="position:fixed; top:0px; left:0px; width:230px; height:100%; background: #ffffff; padding: 10px; font-family:arial; font-size:small; overflow-y:auto;">
	<div style="position:absolute; top:60px; left:10px; width:32px; height:32px; background: #ffffff"><img src="../Pics/VSCodeLogo.gif" alt="logo" border="0"></a>
	</div>
	<a href="https://webservdm.hs-furtwangen.de/dm.php?template=home" target="_blank"><img src="../Pics/logo.png" alt="logo" border="0"></a>
	<p>
		<strong>Veranstaltung "<?php print $title;?>"
		<br/>
		</strong>
		~Dozent/Veranstaltungsleitung
		<br/>
		<br/>
		<?php
		if ($UserRole == "Betreuer" || $UserRole == "Prof") {
			print '
		<form action="' . $currentFile . '" method="POST">
			';
			print '
			<select name="filter" size="1" onchange="submit();">
				<option value="0" ' . ($filter == "0" ? "selected" : "") . '>alle</option>
				<option value="1" ' . ($filter == "1" ? "selected" : "") . '>rot</option>
				<option value="2" ' . ($filter == "2" ? "selected" : "") . '>grün</option>
				<option value="3" ' . ($filter == "3" ? "selected" : "") . '>gelb</option>
			</select>
			<input type="submit" name="form" value="filter" title="Gruppenfilter anwenden">
			';
			print '
		</form>
		';
		}
		?> 
		<br />
		<strong>Anprechpartner</strong>
		<br />
		Fragen/Probleme: <a href="https://github.com/JirkaDellOro/Softwaredesign/issues" target="_blank">Issue anlegen!</a>
		<br/>
		Studies:
		<?php print '<a href="' . $groupmail[0] . '">alle(copy)</a>';?>
		<br/>
		Prof: <?php print('<a href="mailto:' . $profmail . '">bei Katastrophen</a>'); ?>
		<br/>
		<br/>
		<strong>Aufgaben</strong>
		<br>
		Abgabe bis <?php print $deadline;?>!
		<!--br>
		Abschlussarbeit verlängert bis ----.
		<br-->
		<br/>
		<br/>
		<strong><a href="https://github.com/JirkaDellOro/Softwaredesign" target="_blank">
		Repository</a></strong>
		<br/>
		<br/>
		<strong>Startpaket und Registrierung</strong><br />
		<a href="https://jirkadelloro.github.io/EIA2/Steckbrief.zip">Startpaket</a><br />
		<a href="register.php" target="_blank">Steckbrief registrieren</a>
	</p>
	<div style="font-size:x-small; position:fixed; bottom: 0px;left:0px;background: #ffffff;margin:0;padding:2px 10px">
		&copy; Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl, HFU
	</div>
</div>
</body>
</html> 