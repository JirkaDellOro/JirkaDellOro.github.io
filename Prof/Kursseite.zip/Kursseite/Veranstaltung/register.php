<?php
/*
 Validierung und integration der Links zu den Steckbriefen der Teilnehmer
 (c) Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl, HFU
 */
// includes
include "authorize.php";
include "../Code/register.php";
//print("<strong>Achtung: Gruppeneinteilung nach Matrikelnummer (A/B)!!</strong>");
?>