<?php
/* 	authorize.php | (c) Prof. Dipl.-Ing. Jirka R. Dell'Oro-Friedl | HFU
 * 
 * Diverse globalen Variablen für die Kursseiten, insbesondere zur Authorisierung.
 * Kann und sollte bei Bedarf erweitert werden bis Gesamtfuntionalität von hier aus steuerbar.
 */

list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) = explode(':' , base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6)));
if( strlen($_SERVER['PHP_AUTH_USER']) == 0 || strlen($_SERVER['PHP_AUTH_PW']) == 0 ) {
        unset($_SERVER['PHP_AUTH_USER']);
        unset($_SERVER['PHP_AUTH_PW']);
}
 

$UserRole = "";
$User = $_SERVER['PHP_AUTH_USER'];
if ($User == "Student" && $_SERVER['PHP_AUTH_PW'] == "~Passwort") {
	$UserRole = "Student";
} else if (($_SERVER['PHP_AUTH_PW'] == "~Passwort") && ($User == "Betreuer")) {
	$UserRole = "Betreuer";
} else if (($_SERVER['PHP_AUTH_PW'] == "~Passwort") && ($User == "Prof")) {
		$UserRole = "Prof";
} 
else {
	Header('HTTP/1.1 401 Unauthorized');
	Header('WWW-Authenticate: Basic realm="Top Secret"');
	echo "Authorisierter Zugang erforderlich\n";
	//echo "user: ".$_SERVER['PHP_AUTH_USER']." | pass: ".$_SERVER['PHP_AUTH_PW']."\n";
	exit;
}

function getFilename() {
	return 'links.xml';
}

$title = "~Veranstaltungstitel";
$titleExtension = " | ~Dozent | ~Semester";
$nGroups = 1; // ~Anzahl der einzelnen Gruppen
$deadline = "~Abgabetag ~Abgabeuhrzeit Uhr";
$currentFile = $_SERVER["SCRIPT_NAME"];
$parts = Explode('/', $currentFile);
$currentFile = $parts[count($parts) - 1];

$profmail = "~dozent@hs-furtwangen.de,";
$coachmail = array();
$coachmail[0] = "~betreuer@hs-furtwangen.de,";
/*
$coachmail[1] = "~gruppenbetreuer@hs-furtwangen.de,";
$coachmail[2] = "~gruppenbetreuer@hs-furtwangen.de,";
*/
$description = array();
/*
$description[1] = "Mi, 3.Block, L2.07";
$description[2] = "Do, 3.Block, L2.08 (gr&uuml;n)";
$description[3] = "Do, 3.Block, L2.09 (gelb, eigener Rechner)";
$description[4] = "Do, 6.Block, i1.19 (blau, Ravenclaw)";
*/
?>